#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y live-build debootstrap squashfs-tools xorriso
lb clean --purge || true
lb config \
  --distribution trixie \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --debian-installer live \
  --archive-areas "main contrib non-free-firmware" \
  --bootappend-live "boot=live components username=budgie hostname=budgieos"
lb build
