# BudgieOS 1.0 — Budgie Theme Edition

A Debian 13 Live-build project using KDE Plasma, with BudgieOS branding and a
pastel budgerigar visual identity.

## Included
- KDE Plasma desktop and System Settings
- BudgieOS wallpaper artwork
- BudgieOS branding files and starter icon artwork
- Dolphin, Discover, Konsole, Kate, office/browser/media apps
- Network, Bluetooth, sound, display, notifications and desktop widgets
- Live ISO build configuration for amd64

## Build
Use a real Debian 13 (Trixie) PC or VM with internet, administrator access,
and several GB of free space. Android Termux/proot is not a reliable or
supported environment for this ISO build.

```bash
chmod +x build.sh
./build.sh
```

The generated ISO is a functional KDE-based Linux desktop with BudgieOS
branding. It is not yet a fully bespoke operating system: custom installer
screens, a complete icon theme for every application, a custom login/lock
screen implementation, custom sound pack, and the "Your Wingman" assistant
are planned follow-up work, not finished features.
